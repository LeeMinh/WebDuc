﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(SaiGonStreet.Startup))]
namespace SaiGonStreet
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
