﻿
//Jquery for page Index
$(document).ready(function () {
    $("body").delay(100).css("background-image", "url(../Image/bg.png)");
    $(".img-sub-02").animate({ opacity: 1.0, left: '0' }, 1500);
    $(".img-sub-03").animate({ opacity: 1.0, left: '0' }, 1000);
    $(".img-sub-04").delay(500).animate({ opacity: 1.0,top: '0'}, 1500);
    $(".img-sub-05").delay(800).animate({ opacity: 1.0, left: '0' }, 1500);
    $(".img-sub-06").delay(1100).animate({ opacity: 1.0, left: '0' }, 1500);
    $(".img-sub-07").delay(800).animate({ opacity: 1.0, left: '0' }, 1500);
    $(".img-sub-08").delay(800).animate({ opacity: 1.0, left: '0' }, 1500);
    $(".img-sub-10").delay(1100).animate({ opacity: 1.0, left: '0' }, 1500);
    $(".img-sub-11").delay(800).animate({ opacity: 1.0, left: '0' }, 1500);
    $(".img-sub-12").delay(800).animate({ opacity: 1.0, left: '0' }, 1500);
    $(".img-sub-13").delay(800).animate({ opacity: 1.0, left: '0' }, 1500);
    $(".img-sub-14").delay(800).animate({ opacity: 1.0, left: '0' }, 1500);
    $(".img-sub-17").delay(800).animate({ opacity: 1.0, left: '0' }, 1500);
    $(".page-home .menu").delay(800).animate({ opacity: 1.0}, 1500);
});

//Jquery for Menu
$(document).ready(function () {
    (function swing() {
        var ang = 10,
            dAng = 1,
            dir = 1,
            box = document.getElementById("box1");

        (function setAng(ang) {
            box.style.webkitTransform = 'rotate(' + ang + 'deg)';
            dir = -dir;
            if (Math.abs(ang) > 0)
                setTimeout(setAng, 1000, dir * (Math.abs(ang)));
        })(ang);
    })();
    (function swing() {
        var ang = 10,
            dAng = 1,
            dir = 1,
            box = document.getElementById("box2");

        (function setAng(ang) {
            box.style.webkitTransform = 'rotate(' + ang + 'deg)';
            dir = -dir;
            if (Math.abs(ang) > 0)
                setTimeout(setAng, 1000, dir * (Math.abs(ang)));
        })(ang);
    })();
    (function swing() {
        var ang = 10,
            dAng = 1,
            dir = 1,
            box = document.getElementById("box3");

        (function setAng(ang) {
            box.style.webkitTransform = 'rotate(' + ang + 'deg)';
            dir = -dir;
            if (Math.abs(ang) > 0)
                setTimeout(setAng, 1000, dir * (Math.abs(ang)));
        })(ang);
    })();
    (function swing() {
        var ang = 10,
            dAng = 1,
            dir = 1,
            box = document.getElementById("box4");

        (function setAng(ang) {
            box.style.webkitTransform = 'rotate(' + ang + 'deg)';
            dir = -dir;
            if (Math.abs(ang) > 0)
                setTimeout(setAng, 1000, dir * (Math.abs(ang)));
        })(ang);
    })();
});


//Jquery for page Menu
$(document).ready(function () {
    $(".menu .img-menu_01").animate({ opacity: 1.0 }, 500);
    $(".menu .img-menu_02").delay(500).animate({ opacity: 1.0 }, 500);
    $(".menu .img-menu_03").delay(1000).animate({ opacity: 1.0 }, 500);
    $(".menu .img-menu_04").delay(1500).animate({ opacity: 1.0 }, 500);

    $(".slide-menu .slide-menu_01").delay(2000).css("position", "relative").animate({ opacity: 1.0, left: '0' }, 800);
    $(".slide-menu .slide-menu_02").delay(2200).css("position", "relative").animate({ opacity: 1.0, left: '0' }, 800);
    $(".slide-menu .slide-menu_03").delay(2400).css("position", "relative").animate({ opacity: 1.0, left: '0' }, 800);
    $(".slide-menu .slide-menu_04").delay(2600).css("position", "relative").animate({ opacity: 1.0, left: '0' }, 800);
});


//Jquery for page Contact

//$(document).ready(function () {
//    $(".img-contact-1 img").animate({ opacity: 1.0, width: '100%' }, 1500);
//    $(".img-contact .copy").delay(1500).animate({ opacity: 1.0, width: '220' }, 500);
//    $(".img-contact .form").delay(1500).animate({ opacity: 1.0, width: '350' }, 500);
//});


//Jquery for page About
$(document).ready(function () {
    $(".img-book .book").animate({ opacity: 1.0 }, 500);
    $(".img-book .img-about-us_01").delay(600).animate({ opacity: 1.0 }, 1500);
    $(".img-book .copy").delay(600).animate({ opacity: 1.0 }, 1500);
    $(".img-about-us_02 img").delay(600).animate({ opacity: 1.0, width: '100%' }, 1500);
    $(".img-about-us_03 img").delay(600).animate({ opacity: 1.0, width: '100%' }, 1500);
});